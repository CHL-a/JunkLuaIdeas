local mod = {}

--[[
	Some notes: this object should be treated as a wrapper, as such, not everything is under this

]]

local BasicObject = require('BetterOS.BasicObject')
local MainOS = require('BetterOS.MainOS')
local DebugLib = require('BetterOS.Debug')
local idToObjectHashmap = {}

function mod:getDirectableFromId(id)
	return idToObjectHashmap[id]
end

function mod.new(requiredParameters, objectBehaviors)
	-- pre
	assert(
		type(requiredParameters) == 'table' and 
		type(objectBehaviors) == 'table'
	)
	
	local path = requiredParameters.path

	assert(type(path) == 'string')

	local pathInfo = MainOS:getPathInfo(path)

	assert(
		pathInfo.isPath and pathInfo.exists, 
		('invalid path:\npath %s\nispath: %s\nexist: %s\ntraceback:%s'):format(
			path,
			pathInfo.isPath,
			pathInfo.exists,
			debug.traceback()
		)
	)

	-- main
	local object

	local id = MainOS:getIdFromPath(requiredParameters.path)
	
	if not idToObjectHashmap[id] then
		-- properties

		local pathNewIndexed = false
		local parentNewIndexed = false
 
		objectBehaviors.name = objectBehaviors.name or {}
		objectBehaviors.name.type = 'property'
		objectBehaviors.name.onIndexed = function ()
			local path = object.path

			local directories = MainOS:getPathInfo(path).directories

			return directories[#directories]
		end;
		objectBehaviors.name.onNewIndexed = objectBehaviors.name.onNewIndexed or function (_, _, _, v)
			assert(
				type(v) == 'string'
				-- yada yada check for illegal characters
				)
		
			return v
		end
		

		objectBehaviors.parent = {
			type = 'property';
			onNewIndexed = function (_, _, _, v)
				-- pre
				assert(
					not parentNewIndexed or 
					type(v) == 'table' and 
						v.className == 'Folder' and 
						mod:getDirectableFromId(v.uniqueId) == v
				)

				-- main
				if not parentNewIndexed then
					parentNewIndexed = true
				else
					local vObj = mod:getDirectableFromId(v.uniqueId)
					
					MainOS:runCommand(
						([[move %s %s]]):format(
							object.path,
							vObj.path
						)
					)
				end
				
				return v
			end
		}

		objectBehaviors.path = {
			type = 'property';
			onIndexed = function(_, internal)
				-- pre
				if internal.path then
					internal.path = nil
				end
				
				-- main
				return MainOS:getPathFromId(object.uniqueId)
			end;
			onNewIndexed = function()
				-- pre
				assert(not pathNewIndexed, 'read only')

				-- main
				pathNewIndexed = true
			end
		}
		
		objectBehaviors.uniqueId = {
			type = 'property';
			onNewIndexed = function (_, internal, _, v)
				assert(not internal.uniqueId, 'read only')
				return v
			end
		}

		-- methods
		objectBehaviors.destroy = objectBehaviors.destroy or {}
		objectBehaviors.destroy.type = 'function';
		objectBehaviors.destroy.fact = objectBehaviors.destroy.fact or {}
		
		-- instantify
		object = BasicObject.new(requiredParameters, objectBehaviors)

		object.uniqueId = tostring(id)
		object.path = tostring(object.path)
		object.name = tostring(object.name)
		object.parent = nil

		idToObjectHashmap[id] = object
	else
		object = idToObjectHashmap[id]
	end

	return object
end

return mod