local BasicObject = require('Objects.Object')
local Static = require('Objects.Static')

local MainOS


MainOS = BasicObject.new({
	className = 'OperatingSystem';
	indestructible = true;
	irreplicatable = true;
}, {
	-- properties
	tempFolderDirectory = {
		type = 'property';
		onIndexed = function(_, internal, i, v)
			if not v then
				local tempName = os.tmpname()
		
				local directories = Static.string:split(tempName, '\\')
				 -- tempName:split('\\')
				table.remove(directories, #directories)
		
				local parentDirectory = table.concat(directories, '\\')
		
				local struct = MainOS:getPathInfo(parentDirectory)
		
				assert(struct.isPath and struct.exists and struct.pathType == 'directory')
		
				internal[i] = parentDirectory
				v = internal[i]
			end
		
			return v
		end;
		onNewIndexed = function(object, internal, _, v)
			-- pre
			assert(
				not internal.tempFolderDirectory or internal.tempFolderDirectory == v, 
				('read only: internal: %s'):format(
					Static.table:toString(internal)
				)
			)
			
			-- main
			internal.tempFolderDirectory = object.tempFolderDirectory
			return v
		end
	};

	create = {type = 'function';};
	getAvailiblePathName = {type = 'function';};
	getIdFromPath = {type = 'function'};
	getPathFromId = {type = 'function'};
	getPathInfo = {type = 'function'};
	isPath = {type = 'function'};
	pathExists = {type = 'function'};
	rename = {type = 'function'};
	runCommand = {type = 'function';};
	zip = {type = 'function'}
})

function MainOS:create(class, path)
	-- pre
	path = path or MainOS.tempFolderDirectory
	assert(type(path) == 'string' and type(class) == 'string')
			
	local struct = MainOS:getPathInfo(path)
	local command = 
		class == 'file' and 'type nul > %s' or
		class == 'folder' and 'md %s'
	
	local isPath = struct.isPath
	local exists = struct.exists

	assert(
		isPath and not exists and command,
		('got: \npath=%s\nisPath=%s\nexists=%s\ncommand=%s\ntb=%s'):format(
			path, isPath, exists, command, debug.traceback()
		)
	);

	assert(type(command) == 'string')

	command = tostring(command)
	path = tostring(path)

	-- main
	MainOS:runCommand(command:format(path))
end

function MainOS:getAvailiblePathName(parentDirectory, prefix, suffix, iterationStart)
	-- pre
	prefix = prefix or ''
	suffix = suffix or ''
	iterationStart = iterationStart or 0;
	parentDirectory = parentDirectory or MainOS.tempFolderDirectory

	assert(
		type(parentDirectory) == 'string' and 
		type(prefix) == 'string' and 
		type(suffix) == 'string' and 
		type(iterationStart) == 'number'
	)

	parentDirectory = tostring(parentDirectory)
	prefix = tostring(prefix)
	suffix = tostring(suffix)
	iterationStart = tonumber(iterationStart)

	local struct = MainOS:getPathInfo(parentDirectory)

	assert(
		struct.isPath and struct.exists and struct.pathType == 'directory'
	)

	-- main
	local result = {
		fileName = nil;
		iterations = 0
	}

	repeat
		result.iterations = result.iterations + 1

		local path = parentDirectory .. 
			'\\' .. 
			prefix .. 
			result.iterations ..
			suffix
		local pathStruct = self:getPathInfo(path)

		assert(pathStruct.isPath, 'undefined error')

		if not pathStruct.exists then
			result.fileName = path
			break
		end
	until false

	return result
end

function MainOS:getIdFromPath(path)
	-- pre
	local pathInfo = MainOS:getPathInfo(path)

	assert(pathInfo.isPath)

	-- main
	local result

	local output = MainOS:runCommand(
		([[fsutil file queryfileid %s]]):format(path),
		'*l'
	)

	result = tostring(output):match('0x%x+')
	
	return result
end

function MainOS:getPathFromId(id)
	-- pre
	assert(
		type(id) == 'string', 
		'got type ' .. type(id) .. '\ntraceback: ' .. debug.traceback()..'\n'
	)

	id = tostring(id)

	assert(id:sub(1, 2) == '0x' and not id:sub(3):match'%X')

	-- main
	local result
	local output = MainOS:runCommand(
		([[fsutil file queryfilenamebyid C:\ %s]]):format(id),
		'*l'
	)

	result = tostring(output):match('C:\\.+')

	return result
end

function MainOS:getPathInfo(path)
	-- pre
	assert(type(path) == 'string', 'Traceback: ' .. debug.traceback())
	
	path = tostring(path)

	-- main
	local result = {
		isPath = false;
		exists = false;
		directories = nil;
		pathType = nil;
	}

	result.isPath = MainOS:isPath(path)

	if result.isPath then
		result.exists = MainOS:pathExists(path)

		local directories = Static.string:split(path, '\\')
		
		-- path:split("\\")
		local lastDirectory = tostring(directories[#directories])

		result.directories = directories
		result.pathType = lastDirectory:match'%.' and 'file' or 'directory'

		if result.pathType == 'file' then
			local fileType = 
				lastDirectory
				:match('%..+')
				:sub(2)

			result.fileType = fileType
		end
	end

	return result
end

function MainOS:isPath(str)
	-- pre
	assert(type(str) == 'string')

	str = tostring(str)

	-- main
	local result
	local firstDirectory = Static.string:split(str, '\\')
		--str:split('\\')
		[1]

	result = firstDirectory and firstDirectory:sub(#firstDirectory) == ':'

	return result
end

function MainOS:pathExists(path)
	-- pre
	assert(type(path) == 'string')
			
	path = tostring(path)

	-- main
	return 
		MainOS:isPath(path) and 
		MainOS:runCommand(
			('if exist %s (' .. 
				'echo true' ..
			') else ( '..
				'echo false'..
			')'):format(path),
			'*l'
		) == 'true'
end

function MainOS:rename(old, new)
	-- pre
	assert(type(old) == 'string' and type(new) == 'string')
	
	old = tostring(old)
	new = tostring(new)

	local structA = MainOS:getPathInfo(old)
	local structB = MainOS:getPathInfo(new)

	local directoriesA = structA.directories
	local directoriesB = structB.directories

	assert(
		structA.isPath and structA.exists and structA.pathType and #directoriesA >= 1 and
		structB.isPath and not structB.exists and 
			
		structA.pathType == structB.pathType and 
			#directoriesA == #directoriesB,
		'traceback: ' .. debug.traceback()
	)

	local parentDirectory = table.concat(
		{
			unpack(
				directoriesA,
				1,
				#directoriesA - 1
			)
		},
		'\\'
	)

	local oldName = directoriesA[#directoriesA]
	local newName = directoriesB[#directoriesB]

	for i, v in next, directoriesA do
		if i ~= #directoriesA then
			assert(v == directoriesB[i], 'bad: ' .. i)
		end
	end

	-- main
	MainOS:runCommand(('cd %s\nren %s %s'):format(parentDirectory, oldName, newName)
	)
end

function MainOS:runCommand(cmd, mode)
	-- pre
	mode = mode or '*a'
	assert(
		type(cmd) == 'string' and 
		type(mode) == 'string' and mode:sub(1, 1) == '*'
	)

	cmd = tostring(cmd)

	-- main
	local result
	local outputFile = io.popen(cmd)

	assert(outputFile ~= nil, 'error occured in run command')

	result = outputFile:read(mode)

	outputFile:close()

	-- post
	assert(
		result,
		('post conditional unmet: check output. \nCmd: %s\nTraceback: %s'):format(
			cmd,
			debug.traceback()
		)
	)
	--[[
	if cmd:find'fsutil file queryfilenamebyid ' then
		print(('cmd:%s\ntb: %s'):format(cmd, debug.traceback()))
	end]]
	return result
end

function MainOS:zip(...)
	-- in: array of directable objects
	-- out: zip file

	-- pre
	local args = {...}

	assert(#args ~= 0)

	for _, v in next, args do
		assert(
			type(v) == 'table' and (
				v.className == 'Folder' or 
				v.className == 'File') and 
				require('BetterOS.DirectableObject'):getDirectableFromId(v.uniqueId)
		)
	end

	-- main
	local File = require('BetterOS.File')
	local Folder = require('BetterOS.Folder')
	
	local tempFolder = Folder.new()

	for _, v in next, args do
		v = (v.className =='Folder' and Folder or File).new(v.path)
		v:clone().parent = tempFolder
	end
	
	local newZipPath = MainOS:getAvailiblePathName(nil, 'zip', '.zip').fileName

	local cmd = ('tar -acf %s -C%s *.*\n'):format(
		newZipPath,
		tempFolder.path
	) -- this cmd fails of cd is met

	print(
		MainOS:runCommand(cmd)
	)
	-- os.execute(cmd)

	local zipFile = File.new(newZipPath)

	tempFolder:destroy()

	return zipFile
end

MainOS.tempFolderDirectory = tostring(MainOS.tempFolderDirectory)

return MainOS