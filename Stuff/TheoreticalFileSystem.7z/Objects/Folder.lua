local module = {}
local directableObject = require('BetterOS.DirectableObject')
local MainOS = require('BetterOS.MainOS')
local DebugLib = require('BetterOS.Debug')

local folderCache = {}

function module.new(arg1, arg2)
	-- pre
	if type(arg1) == 'string' then
		-- use an existing folder
		local pathInfo = MainOS:getPathInfo(arg1)
		
		assert(
			pathInfo.isPath and 
			pathInfo.exists and 
			pathInfo.pathType == 'directory'
		)
	else
		-- create a folder
		if not arg2 then
			local fileName = MainOS:getAvailiblePathName(nil, 'TEMPFOLDER_').fileName
			local pathInfo = MainOS:getPathInfo(fileName)

			arg2 = pathInfo.directories[#pathInfo.directories]
		end
		

		assert(type(arg2) == 'string')

		if type(arg1) == 'table' then
			assert(
				type(arg1) == 'table' and 
				type(arg1.uniqueId) == 'string' and 
				directableObject:getDirectableFromId(arg1.uniqueId)
			)
		elseif arg1 ~= nil then
			error('bad arg type')
		end
	end

	-- main
	local parentPath, fullPathName
	local object

	parentPath = 
		arg1 == nil and MainOS.tempFolderDirectory or 
		type(arg1) == 'table' and arg1.path

	fullPathName = 
		parentPath and parentPath .. '\\' .. arg2 or
		arg1
	
	if parentPath then -- create folder
		MainOS:create('folder', fullPathName)
	end
	
	local id = MainOS:getIdFromPath(fullPathName)

	if folderCache[id] then
		object = folderCache[id]
	else
		local fullPathInfo = MainOS:getPathInfo(fullPathName)
		local directories = fullPathInfo.directories

	
		object = directableObject.new({
			className = 'Folder',
			path = fullPathName
		}, {
			-- properties

			-- functions
			clone = {type = 'function';};
			destroy = {
				type = 'function';
				fact = {function (oldFunc)
					return function()
						for _, v in next, object:getChildren() do
							v:destroy()
						end

						MainOS:runCommand(('rd %s'):format(object.path))

						oldFunc()
					end
				end}
			};
			getChildren = {type = 'function'};
			zip = {type = 'function'}
		})

		function object:getChildren()
			local result = {}
			
			local paths = MainOS:runCommand(
				('dir %s /b'):format(object.path)
			):split('\n', true)
			
			table.remove(paths, #paths)

			for _, v in next, paths do
				local fullPath = object.path .. '\\' .. v
				local id = MainOS:getIdFromPath(fullPath)
				local pathInfo = MainOS:getPathInfo(fullPath)

				local insertV

				if directableObject:getDirectableFromId(id) then
					insertV = directableObject:getDirectableFromId(id)
				else
					assert(pathInfo.isPath and pathInfo.exists)

					insertV = 
						pathInfo.pathType == 'directory' and 
							module.new(fullPath) or
						pathInfo.pathType == 'file' and 
							require('BetterOS.File').new(fullPath)

				end

				table.insert(result, insertV)
			end

			return result
		end

		function object:clone(parentFolder)
			-- pre
			if parentFolder then
				assert(
					type(parentFolder) == 'table' and 
					parentFolder.className == 'Folder'
				)

				parentFolder = module.new(parentFolder.path)
			end

			local pathInfo = MainOS:getPathInfo(object.path)

			assert(pathInfo.isPath and pathInfo.exists)

			-- main
			local newObject
			local parentPath = parentFolder and 
				parentFolder.path or 
				table.concat(pathInfo.directories, '\\', 1, #pathInfo.directories - 1)

			-- get name
			local name = object.name;
			local iteration = 0;
			
			repeat
				local newPath = ('%s\\%s'):format(parentPath, name)
				local newPathInfo = MainOS:getPathInfo(newPath)

				assert(newPathInfo.isPath, 'p' .. newPath)

				if newPathInfo.exists then
					iteration = iteration + 1
					name = object.name .. iteration
				end

			until not newPathInfo.exists

			-- construct
			newObject = module.new(parentFolder or object.parent, name)

			MainOS:runCommand(('xcopy %s %s /e'):format(
				object.path,
				newObject.path
			))

			return newObject
		end

		folderCache[id] = object

		object.name = directories[#directories]

		if type(arg1) == 'table' then
			object.parent = module.new(arg1.path)
		--[[ -- idk fix later?
		elseif type(arg1) == 'string' then 
			local path = object.path
			local pathInfo = MainOS:getPathInfo(path)

			if pathInfo.isPath and pathInfo.exists and pathInfo.pathType == 'directory' then
				local newPath = table.concat(
					pathInfo.directories, 
					'\\', 
					1, 
					#pathInfo.directories - 1
				)

				object.parent = module.new(newPath)
			end
			]]
		end
	end
	
	return object
end

return module