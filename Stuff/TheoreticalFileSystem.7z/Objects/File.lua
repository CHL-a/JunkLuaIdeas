local module = {}
local directableObject = require('BetterOS.DirectableObject')
local MainOS = require('BetterOS.MainOS')
local DebugLib = require('BetterOS.Debug')

local fileCache = {}

function module.new(arg1, arg2, arg3)
	-- pre
	if type(arg1) == 'string' then
		-- use an existing file
		local pathInfo = MainOS:getPathInfo(arg1)
		
		assert(
			pathInfo.isPath and 
			pathInfo.exists and 
			pathInfo.pathType == 'file',
			('path: %s\ntraceback: %s'):format(
				arg1,
				debug.traceback()
			)
		)
	else
		-- create a file
		arg3 = arg3 or 'txt'

		if not arg2 then
			local path = MainOS:getAvailiblePathName(nil, 'TEMPFILE_', '.' .. arg3).fileName
			local pathInfo = MainOS:getPathInfo(path)

			arg2 = pathInfo.directories[#pathInfo.directories]
				:match'[^%.]+'
		end

		assert(
			type(arg2) == 'string' and 
			type(arg3) == 'string',
			tostring(arg2) .. ', ' .. tostring(arg3)
		)
		

		if type(arg1) == 'table' then
			assert(
				type(arg1) == 'table' and 
				type(arg1.uniqueId) == 'string' and 
				directableObject:getDirectableFromId(arg1.uniqueId)
			)
		elseif arg1 ~= nil then
			error('bad arg type')
		end
	end

	-- main
	local parentPath, fullPathName
	local object

	parentPath = 
		arg1 == nil and MainOS.tempFolderDirectory or 
		type(arg1) == 'table' and arg1.path
	fullPathName = 
		parentPath and parentPath .. '\\' .. arg2 .. '.' .. arg3 or
		arg1

	if parentPath then -- create file
		MainOS:create('file', fullPathName)
	end
	
	local id = MainOS:getIdFromPath(fullPathName)

	if fileCache[id] then
		object = fileCache[id]
	else
		local fullPathInfo = MainOS:getPathInfo(fullPathName)
		local directories = fullPathInfo.directories
		object = directableObject.new(
			{
				className = 'File',
				path = fullPathName
			},{
				-- properties
				fileName = {
					type = 'property';
					onIndexed = function()
						local name = object.name
						local fileName = name:match('[^%.]+')

						return fileName
					end;
					onNewIndexed = function (_, _, _, v)
						assert(type(v) == 'string')

						object.name = v .. '.' .. object.fileType
						return v
					end
				};
				fileType = {
					type = 'property';
					onIndexed = function()
						local name = object.name
						local fileType = name:match('%..+'):sub(2)

						return fileType
					end;
					onNewIndexed = function (_, _, _, v)
						assert(type(v) == 'string')

						object.name = object.fileName .. '.' .. v
						return v
					end
				};
				name = {
					type = 'property';
					onNewIndexed = function (_, internal, _, v)
						-- pre
						assert(type(v) == 'string')
						v = tostring(v)
						local dotFind = v:find('%.')
						assert(dotFind)

						-- main
						local fileName = v:sub(1, dotFind - 1)
						local fileType = v:sub(dotFind + 1)

						internal.fileName = fileName
						internal.fileType = fileType

						return v
					end
				};

				-- functions
				destroy = {
					type = 'function';
					fact = {function (oldFunc)
						return function()
							MainOS:runCommand(('erase %s'):format(object.path))

							oldFunc()
						end
					end}
				};
				read = {type = 'function'};
				write = {type = 'function'};
				clone = {type = 'function'}
			}
		)

		fileCache[id] = object

		object.name = directories[#directories]
		object.fileName = tostring(object.fileName)
		object.fileType = tostring(object.fileType)

		function object:read()
			local file = io.open(object.path, 'r+b')

			local result = file:read('*a')

			file:close()

			return result
		end

		function object:write(s)
			assert(type(s) == 'string')

			local file = io.open(object.path, 'w+b')

			file:write(s)

			file:close()
		end

		function object:clone(parentFolder)
			-- pre
			if parentFolder then
				assert(
					type(parentFolder) == 'table' and 
					parentFolder.className == 'Folder'
				)

				parentFolder = require('BetterOS.Folder').new(parentFolder.path)
			end
			
			local pathInfo = MainOS:getPathInfo(object.path)

			assert(pathInfo.isPath and pathInfo.exists)

			-- main
			local newObject

			-- get name
			local name = object.fileName;
			local iteration = 0;
			local parentPath = parentFolder and 
				parentFolder.path or 
				table.concat(pathInfo.directories, '\\', 1, #pathInfo.directories - 1)
			
			repeat
				local newPath = ('%s\\%s.%s'):format(parentPath, name, object.fileType)
				local newPathInfo = MainOS:getPathInfo(newPath)

				assert(newPathInfo.isPath, 'p' .. newPath)

				if newPathInfo.exists then
					iteration = iteration + 1
					name = object.fileName .. iteration
				end
			until not newPathInfo.exists

			-- construct
			newObject = module.new(
				parentFolder or object.parent,
				name,
				object.fileType
			)

			newObject:write(object:read())

			return newObject
		end
	end
	
	return object
end

return module