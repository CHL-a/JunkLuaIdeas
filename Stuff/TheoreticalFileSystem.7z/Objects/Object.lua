local mod = {}
local internalHashmap = {}
local availibleId = 1

local Static = require('Objects.Static')

function mod:getObject(id)
	-- pre
	assert(type(id) == 'string')
	local object = internalHashmap[id]

	assert(object, 'non exist')

	-- main

	return object
end

function mod.new(requiredParameters, objectBehaviors)
	-- pre
	assert(
		type(requiredParameters) == 'table' and 
			type(requiredParameters.className) == 'string' and
		type(objectBehaviors) == 'table'
	)

	requiredParameters.indestructible = not not requiredParameters.indestructible
	
	-- main
	local object = {}
	local internal = requiredParameters.internalStateCopy or {
		className = requiredParameters.className;
		objectId = tostring(availibleId)
	}
	
	availibleId = availibleId + 1

	-- defaults
	objectBehaviors.className = {
		type = 'property';
		onNewIndexed = function(_, _, _, v)
			-- pre
			assert(v == internal.className, 'intangible')

			-- main
			return v
		end
	};

	objectBehaviors.objectId = {
		type = 'property';
		onNewIndexed = function(_, _, _, v)
			-- pre
			assert(
				v == internal.objectId,
				'read only: traceback: ' .. 
				debug.traceback() .. 
				'\n'
			)

			-- main
			return v
		end
	};

	if not requiredParameters.indestructible then
		objectBehaviors.destroy = objectBehaviors.destroy or {}
		objectBehaviors.destroy.type = 'function';
	end

	-- another set check
	--[[
	for _, v in next, objectBehaviors do
		if v.type == 'function' and type(v.fact) == 'table' then
			while #v.fact >= 1 do
				local fact = v.fact[1]

				v.func = fact(v.func, internal)

				table.remove(v.fact, 1)
			end
		end
	end
	]]

	-- setmetatable
	setmetatable(object, {
		__index = function (_, i)
			local result
			local struct = objectBehaviors[i]

			if struct then
				result = 
					struct.type == 'property' and 
						(struct.onIndexed and 
						{struct.onIndexed(object, internal, i, internal[i])} or
						{internal[i]}) or
					struct.type == 'function' and
						struct.func
			end

			-- post
			assert(
				result, 
				'Index: ' .. i .. 
				'\nStruct: ' .. (struct and Static.table:toString(struct) or 'no struct').. 
				'\nTraceback: ' .. debug.traceback() .. '\n')

			return 
				type(result) == 'function' and result or 
				unpack(result)
		end;
		__newindex = function(_, i, v)
			local struct = objectBehaviors[i]

			if struct then
				if struct.type == 'property' then
					if struct.onNewIndexed then
						internal[i] = struct.onNewIndexed(object, internal, i, v)
					end
				elseif struct.type == 'function' then
					assert(not struct.func, 'function already exists')
					
					local currentFunc = v

					if struct.fact then
						for _, fact in next, struct.fact do
							currentFunc = fact(currentFunc)
						end
					end

					struct.func = currentFunc
				else
					error('got bad type ' .. struct.type)
				end
			end
		end;
		__tostring = function()
			local clone = {}

			for i, v in next, internal do
				if type(v) == 'table' then
					v = mod:getObject(v.objectId or '') and 
						setmetatable({},{__tostring = function()
							return ('(OBJECT: %s)'):format(v.objectId)
						end}) or 
						v
				end

				clone[i] = v
			end

			return Static.table:toString(clone)
		end
	})

	internalHashmap[internal.objectId] = object

	-- post
	object.className = tostring(object.className)
	object.objectId = tostring(object.objectId)

	if not requiredParameters.indestructible then
		function object:destroy()
			local objectId = internal.objectId

			for i in next, internal do
				internal[i] = nil
			end

			local metatable = getmetatable(object)

			metatable.__index = function ()error'destroyed object, considered intangible'end
			metatable.__newindex = metatable.__index
			
			internalHashmap[objectId] = nil
		end
	end

	--[[
	if not requiredParameters.irreplicatable then
		function object:clone()
			local internalCopy = {}
			local requiredParametersCopy = {}

			for i, v in next, internal do
				internalCopy[i] = v
			end

			for i,v in next, requiredParameters do
				requiredParametersCopy[i] = v
			end

			requiredParametersCopy.internalStateCopy = internalCopy
			
			return mod.new(requiredParametersCopy, objectBehaviors)
		end
	end
	--]]
	return object
end

return mod
